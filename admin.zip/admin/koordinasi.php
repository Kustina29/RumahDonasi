<?php
$conn = new mysqli("localhost", "root", "", "db_rumahdonasi");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id_barang = $_POST['id_barang'];
    $penerima = $_POST['penerima'];
    $tanggal = $_POST['tanggal_penyaluran'];

    $stmt = $conn->prepare("INSERT INTO tbl_penyaluran (id_barang, penerima, tanggal_penyaluran) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $id_barang, $penerima, $tanggal);
    if ($stmt->execute()) {
        echo "<script>alert('Jadwal penyaluran berhasil disimpan');</script>";
    } else {
        echo "<script>alert('Gagal menyimpan data');</script>";
    }
    $stmt->close();
}

// Ambil data barang yang sudah diverifikasi layak
$barang = $conn->query("SELECT * FROM tbl_barang WHERE status_verifikasi = 'layak'");
?>

<?php
$conn = new mysqli("localhost", "root", "", "db_rumahdonasi");

if ($conn->connect_error) {
die("Koneksi gagal: " . $conn->connect_error);
}

// Update jika form disubmit
if ($_SERVER["REQUEST_METHOD"] === "POST") {
$id = $_POST['id'];
$status = $_POST['status'];
$catatan = $_POST['catatan'];

$stmt = $conn->prepare("UPDATE tbl_barang SET status_verifikasi=?, catatan_admin=? WHERE id_barang=?");
$stmt->bind_param("ssi", $status, $catatan, $id);
$stmt->execute();
$stmt->close();
}

// Ambil data barang yang belum diverifikasi
$result = $conn->query("SELECT * FROM tbl_barang WHERE status_verifikasi = 'belum'");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Verifikasi Barang</title>
<style>
table { width: 100%; border-collapse: collapse; margin-top: 20px; }
th, td { padding: 10px; border: 1px solid #ccc; text-align: left; }
form { display: inline-block; }
select, textarea, button { margin: 4px 0; }
</style>
</head>
<body>
<h2>Seleksi & Verifikasi Kelayakan Barang</h2>

<table>
<thead>
    <tr>
    <th>Nama Barang</th>
    <th>Verifikasi</th>
    <th>Catatan</th>
    <th>Aksi</th>
    </tr>
</thead>
<tbody>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['nama_barang']) ?></td>
        <td>
        <form method="POST">
            <input type="hidden" name="id" value="<?= $row['id_barang'] ?>">
            <select name="status" required>
            <option value="layak">Layak</option>
            <option value="tidak_layak">Tidak Layak</option>
            </select>
        </td>
        <td>
            <textarea name="catatan" rows="2" cols="25" placeholder="Catatan..."></textarea>
        </td>
        <td>
            <button type="submit">Simpan</button>
        </form>
        </td>
    </tr>
    <?php endwhile; ?>
</tbody>
</table>
</body>
</html>

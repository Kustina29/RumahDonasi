<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_rumahdonasi");

if ($conn->connect_error) {
die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['upload'])) {
$id = $_POST['id'];
$file = $_FILES['bukti'];

if ($file['error'] === 0) {
$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = "bukti_" . time() . "." . $ext;
$targetPath = "uploads/" . $filename;

if (move_uploaded_file($file['tmp_name'], $targetPath)) {
    $conn->query("UPDATE distribusi SET bukti = '$filename' WHERE id = $id");
}
}
}

$result = $conn->query("SELECT * FROM distribusi ORDER BY tanggal DESC");
?>
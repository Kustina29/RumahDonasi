<?php
$conn = new mysqli("localhost", "root", "", "db_rumahdonasi");
if ($conn->connect_error) {
die("Koneksi gagal: " . $conn->connect_error);
}

// Update aksi
if ($_SERVER["REQUEST_METHOD"] === "POST") {
$id = $_POST['id'];
$aksi = $_POST['aksi'];
$stmt = $conn->prepare("UPDATE tbl_barang SET aksi_tidak_layak=? WHERE id_barang=?");
$stmt->bind_param("si", $aksi, $id);
$stmt->execute();
$stmt->close();
}

// Ambil data barang tidak layak
$result = $conn->query("SELECT * FROM tbl_barang WHERE status_verifikasi = 'tidak_layak'");
?>